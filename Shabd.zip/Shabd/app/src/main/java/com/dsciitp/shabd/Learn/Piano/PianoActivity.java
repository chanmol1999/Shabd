package com.dsciitp.shabd.Learn.Piano;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.dsciitp.shabd.R;

public class PianoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_piano);
    }
}
