package com.dsciitp.shabd;

import android.net.Uri;

public class UserConstants {

    public static String email;
    public static String displayName;
    public static String phone;
    public static Uri photoUri;


}
